 context.setVariable("request.verb", "GET");
 var url = "http://httpbin.org/get";
 context.setVariable("target.url", url);