var statusCode = context.getVariable('response.status');
print(statusCode);