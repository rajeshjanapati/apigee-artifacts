// FL implemented -- Domain name, hostname, session path, siteId, region, cachedservices, 
sessionId = content.getVariable("session.id");
registerId = context.getVariable("register.id");
