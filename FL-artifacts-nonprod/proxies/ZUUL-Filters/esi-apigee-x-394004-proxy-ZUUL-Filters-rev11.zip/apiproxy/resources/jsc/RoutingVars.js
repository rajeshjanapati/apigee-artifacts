// FL implemented -- Domain name, hostname, session path, siteId, region, cachedservices, 
sessionId = context.getVariable("session.id");
registerId = context.getVariable("register.id");
