var sessionId = context.getVariable("session.id");
context.setVariable("request.header.jwt-token", "lkjhgsdfghrtyu");
context.setVariable("request.header.isAuthenticated", "true");